<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Student Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }
        .container {
            position: relative;
            max-width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            justify-content: center;
            padding: 40px;
            background-image: url('portal.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            position: absolute;
            top: 20px;
            right: 20px;
            color: #333; /* Dark font color */
            font-size: 36px;
        }
        .btn-container {
            display: flex;
            flex-direction: column; /* Display buttons line by line */
            align-items: center; /* Center align buttons */
            margin-top: 20px; /* Add some margin */
        }
        .btn {
            display: inline-block;
            padding: 15px 40px;
            margin: 10px;
            text-decoration: none;
            color: #fff;
            background-color: #4CAF50; /* Change button color */
            border-radius: 25px; /* Rounded corners */
            font-size: 20px;
            transition: background-color 0.3s;
            cursor: pointer;
            border: none; /* Remove border */
            outline: none; /* Remove outline */
        }
        .btn:hover {
            background-color: #45a049; /* Change button hover color */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>WELCOME TO STUDENT PORTAL</h1>
        <div class="btn-container">
            <a href="#" onclick="redirectTo('login.php')" class="btn">Login as Student</a>
            <a href="#" onclick="redirectTo('login_teacher.php')" class="btn">Login as Teacher</a>
            <a href="#" onclick="redirectTo('admin_dashboard.php')" class="btn">Login as Admin</a>
        </div>
    </div>

    <script>
        function redirectTo(url) {
            window.location.href = url;
        }
    </script>
</body>
</html>

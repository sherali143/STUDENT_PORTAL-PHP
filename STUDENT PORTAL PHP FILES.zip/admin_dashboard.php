<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
<style>
    body {
        font-family: 'Montserrat', sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f6f6f6; /* Light gray background */
    }
    .sidebar {
        width: 200px;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        background-color: #333; /* Dark background color */
        padding-top: 20px;
        transition: width 0.3s; /* Smooth width transition */
        z-index: 1; /* Ensure sidebar is above other content */
    }
    .sidebar a {
        display: flex; /* Use flexbox for layout */
        flex-direction: column; /* Stack symbol and title vertically */
        align-items: center; /* Center-align items horizontally */
        width: 100%;
        padding: 15px;
        margin-bottom: 5px;
        text-align: center;
        text-decoration: none;
        color: #fff; /* White text color */
        transition: background-color 0.3s, color 0.3s; /* Smooth color transition */
    }
    .sidebar a:hover {
        background-color: #555; /* Darker background color on hover */
    }
    .icon {
        font-size: 1.5em; /* Larger font size for symbol */
        margin-bottom: 5px; /* Add some space between symbol and title */
    }
    .container {
        margin-left: 200px; /* Adjusted margin for sidebar width */
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
    }
    .section {
        display: none; /* Hide all sections initially */
    }
    .section.active {
        display: block; /* Show active section */
    }
    .welcome {
        font-size: 24px;
        text-align: center;
        margin-bottom: 20px;
        color: #333; /* Dark text color */
    }
</style>
</head>
<body>

<div class="sidebar">
    <a href="#" class="button" onclick="showSection('home')">
        <span class="icon">🏠</span>
        <span class="title">Dashboard</span>
    </a>
    <a href="#" class="button" onclick="showSection('manage-teachers')">
        <span class="icon">👥</span>
        <span class="title">Manage Teachers</span>
    </a>
    <a href="#" class="button" onclick="showSection('manage-courses')">
        <span class="icon">📚</span>
        <span class="title">Teacher Courses</span>
    </a>
    <a href="#" class="button" onclick="showSection('manage_students')">
        <span class="icon">✉️</span>
        <span class="title">Manage Students</span>
    </a>
</div>

<div class="container">
    <div id="home" class="section active">
        <div class="welcome">Welcome to the Admin Dashboard!</div>

        <?php
        $server_name = "localhost";
        $user_name = "root";
        $password = "";
        $database = "student_portal";
        $conn = mysqli_connect($server_name, $user_name, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT * FROM admin";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            echo "<table>";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                // Display name and title in two boxes
                echo "<td class='box'><strong>Name:</strong> " . $row['name'] . "</td>";
                echo "<td class='box'><strong>Title:</strong> " . $row['title'] . "</td>";
                echo "</tr>";
                // Display address and campus in two boxes
                echo "<tr>";
                echo "<td class='box'><strong>Address:</strong> " . $row['address'] . "</td>";
                echo "<td class='box'><strong>Campus:</strong> " . $row['campus'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
        
        
        

        mysqli_close($conn);


    ?>
        <!-- Home section content -->
    </div>

    <div id="manage-teachers" class="section">
    <div class="welcome">Manage Teachers</div>
    <?php
    $server_name = "localhost";
    $user_name = "root";
    $password = "";
    $database = "student_portal";
    $conn = mysqli_connect($server_name, $user_name, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM instructors";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<p><strong>Instructor ID:</strong> " . $row['instructor_id'] . "</p>";
            echo "<p><strong>Instructor Name:</strong> " . $row['instructor_name'] . "</p>";
            echo "<hr>"; // Add a horizontal line for separation
        }
    }
    echo "<button onclick='add_teacher()'>ADD</button>";
    echo "<button onclick='delete_teacher()'>DELETE</button>";

    mysqli_close($conn);
?>

</div>

    <div id="manage-courses" class="section">

        <?php
    $server_name = "localhost";
    $user_name = "root";
    $password = "";
    $database = "student_portal";
    $conn = mysqli_connect($server_name, $user_name, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT courses.instructor_id, instructors.instructor_name, courses.course_name FROM courses JOIN instructors ON courses.instructor_id = instructors.instructor_id;";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<p><strong>Instructor ID:</strong> " . $row['instructor_id'] . "</p>";
            echo "<p><strong>Instructor Name:</strong> " . $row['instructor_name'] . "</p>";
            echo "<p><strong>Course Name:</strong> " . $row['course_name'] . "</p>";
            echo "<hr>"; // Add a horizontal line for separation
        }
    }
    echo "<button onclick='add_course()'>ADD</button>";
    mysqli_close($conn);
?>

          <!-- Your content for the "Manage Courses" section goes here -->
    </div>


    <div id="manage_students" class="section">
        <div class="welcome">Manage Students</div>
        <?php
    $server_name = "localhost";
    $user_name = "root";
    $password = "";
    $database = "student_portal";
    $conn = mysqli_connect($server_name, $user_name, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT spi.student_id, spi.student_name, c.course_name 
            FROM student_personal_information spi 
            JOIN student_course sc ON spi.student_id = sc.student_id 
            JOIN courses c ON sc.course_id = c.course_id";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<p><strong>Student ID:</strong> " . $row['student_id'] . "</p>";
            echo "<p><strong>Student Name:</strong> " . $row['student_name'] . "</p>";
            echo "<p><strong>Course Name:</strong> " . $row['course_name'] . "</p>";
            echo "<hr>"; // Add a horizontal line for separation
        }
    } else {
        echo "No students found.";
    }

    echo "<button onclick='add_student()'>ADD STUDENT</button>";
    echo "<button onclick='view_student()'>VIEW STUDENT</button>";
    echo "<button onclick='add_student_course()'>ADD STUDENT COURSE</button>";
    echo "<button onclick='delete_student()'>DELETE STUDENT</button>";

    mysqli_close($conn);
?>

    </div>

</div>

<script>
function showSection(sectionName) {
    var sections = document.querySelectorAll('.section');
    sections.forEach(function(section) {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');
}
</script>



<script>
function add_teacher() {
    var instructor_id = prompt("Enter the instructor id you want to add");
    var instructor_name = prompt("Enter the instructor name you want to add");
    var instructor_title = prompt("Enter the instructor title you want to add");
    var instructor_email = prompt("Enter the instructor email you want to add");
    var instructor_password = prompt("Enter the instructor password you want to add");

    if (instructor_id && instructor_name && instructor_title && instructor_email && instructor_password) {
        window.location.href = "add_teacher.php?instructor_id=" + instructor_id + "&instructor_name=" + instructor_name + "&instructor_title=" + instructor_title + "&instructor_email=" + instructor_email + "&instructor_password=" + instructor_password;
    }
}

</script>


<script>
function delete_teacher() {
    var instructor_id = prompt("Enter the instructor id you want to delete");

    if (instructor_id ) {
        window.location.href = "delete_teacher.php?instructor_id=" + instructor_id ;
}
}
</script>

<script>
function add_course()
    {   
        var course_id = prompt("Enter the course id");
        var course_name = prompt("Enter the course name");
        var course_title = prompt("Enter the course title");
        var instructor_id = prompt("Enter the instructor id");
        
        window.location.href= "add_course.php?course_id="+ course_id + "&course_name=" + course_name + "&course_title=" + course_title + "&instructor_id=" + instructor_id ;

    }

</script>

<script>
function add_student()
    {   
        var student_id = prompt("Enter the student id");
        var student_name = prompt("Enter the student name");
        var student_batch = prompt("Enter the student batch");
        var student_cnic = prompt("Enter the student cnic");
        var student_father_name = prompt("Enter the student father name");
        var student_campus = prompt("Enter the student campus");
        var student_degree = prompt("Enter the student degree");
        var student_email = prompt("Enter the student email");
        var password = prompt("Enter the password for student");
        
        window.location.href= "add_student.php?student_id="+ student_id + "&student_name=" + student_name + "&student_batch=" + student_batch + "&student_cnic=" + student_cnic + "&student_father_name= "+ student_father_name + "&student_campus=" + student_campus + "&student_degree=" + student_degree + "&student_email=" + student_email + "&password="+ password;

    }

</script>


<script>
function view_student()
    {   
        
        window.location.href= "view_student.php" ;
    }

</script>

<script>
function add_student_course()
    {   
        var student_id = prompt("Enter the student id");
        var course_id = prompt("Enter the course id");
        
        window.location.href= "add_student_course.php?student_id="+ student_id + "&course_id=" + course_id ;

    }

</script>


<script>
function delete_student()
    {   
        var student_id = prompt("Enter the student id");  
        window.location.href= "delete_student.php?student_id="+ student_id;

    }

</script>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Portal Dashboard</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }
    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    h1 {
        text-align: center;
        margin-bottom: 20px;
        color: #333;
    }
    .section {
        margin-bottom: 20px;
        border-radius: 5px;
        overflow: hidden;
        background-color: #f9f9f9;
    }
    .section h2 {
        color: #fff;
        background-color: #333;
        padding: 10px;
        margin: 0;
    }
    .info {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }
    .info div {
        padding: 10px;
        border-bottom: 1px solid #ccc;
    }
    .info div:last-child {
        border-bottom: none;
    }
    .info div strong {
        color: #333;
    }
</style>
</head>
<body>
    <div class="container">
        <h1>Teacher Portal Dashboard</h1>
        <div class="section">
            <h2>University Information</h2>
            <div class="info">
                <div>
                    <strong>Name:</strong> University Name
                </div>
                <div>
                    <strong>Title:</strong> Your Degree
                </div>
                <div>
                    <strong>Email:</strong> Campus Name
                </div>
                <div>
                    <strong>Password:</strong> Section Name
                </div>
            </div>
        </div>
        
    </div>
</body>
</html>


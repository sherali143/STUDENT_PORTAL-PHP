<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $server_name = "localhost";
    $user_name = "root";
    $password = "";
    $database = "student_portal";
    $conn = mysqli_connect($server_name, $user_name, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $name = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT student_id FROM student_personal_information WHERE student_name = '$name' AND password = '$password'";

    $result = mysqli_query($conn, $sql);

    if ($result) 
    {
        if (mysqli_num_rows($result) > 0)
        {
            $row = mysqli_fetch_assoc($result);
            $student_id = $row['student_id'];
            $_SESSION['student_id']= $student_id;
            header("location: student_dashboard.php");
            exit();
        } 
        else 
        {
            echo "No records found for this user. Kindly contact admin!";
        }
    } 
    else 
    {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
 
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 0;
        }
        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .login-form {
            text-align: center;
        }
        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        .login-form input[type="submit"] {
            width: 100%;
            padding: 15px;
            font-size: 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .login-form input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form class="login-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>

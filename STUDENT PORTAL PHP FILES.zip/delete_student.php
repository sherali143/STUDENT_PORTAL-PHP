<?php

$server_name = "localhost";
$user_name = "root";
$password = "";
$database = "student_portal";

$conn = mysqli_connect($server_name, $user_name, $password, $database);

// Check if student_id is provided in the URL
if(isset($_GET['student_id']))  
{
    $student_id = $_GET['student_id'];
    
    // Prepare and execute the SQL query to delete the student record
    $sql = "DELETE FROM student_personal_information WHERE student_id = '$student_id'";
    $result = mysqli_query($conn, $sql);

    // Check if the query was executed successfully
    if($result) 
    {
        // Check if any rows were affected (i.e., if a record was deleted)
        if(mysqli_affected_rows($conn) > 0)
        {
            echo "Student Record Deleted successfully.";
        }
        else
        {
            echo "No record found for this Student.";
        }
    } 
    else
    {
        // Display an error message if the query failed
        echo "Error Deleting Student: " . mysqli_error($conn);
    }
}
else
{
    // Display an error message if student_id is not provided in the URL
    echo "Error: Student ID not provided.";
}

// Close the database connection
mysqli_close($conn);

?>

<?php

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

if(isset($_GET['instructor_id']) && isset($_GET['instructor_name'])  && isset($_GET['instructor_title']) && isset($_GET['instructor_email']) && isset($_GET['instructor_password'])); 
{
    $instructor_id =   $_GET['instructor_id'];
    $instructor_name = $_GET['instructor_name'];
    $instructor_title = $_GET['instructor_title'];
    $instructor_email = $_GET['instructor_email'];
    $instructor_password = $_GET['instructor_password'];
    // Perform the database update
    $sql = "insert into instructors (instructor_id,instructor_name,instructor_title,instructor_email,instructor_password) values ('$instructor_id','$instructor_name','$instructor_title','$instructor_email','$instructor_password')";

    $result = mysqli_query($conn, $sql);

    if($result) 
    {
        if(mysqli_affected_rows($conn))
        {
            echo "Teacher ADDED successfully.";
        }
        else
        {
            echo "No record Found For this Student";
        }
        
    } 
    else
    {
        echo "Error Adding Teachers: " . mysqli_error($conn);
    }
} 


?>

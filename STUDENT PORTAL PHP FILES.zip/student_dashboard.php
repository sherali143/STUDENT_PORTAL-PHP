<?php
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit(); // Stop further execution
}

// Retrieve the student ID from the session
$student_id = $_SESSION['student_id'];

// Initialize student name variable
$student_name = "";
$student_degree = "";
$student_campus = "";
$student_batch = "";

// Database connection parameters
$server_name = "localhost";
$user_name = "root";
$password = "";
$database = "student_portal";

// Create connection
$conn = mysqli_connect($server_name, $user_name, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to retrieve student name
$sql = " SELECT * FROM student_personal_information WHERE student_id = '$student_id' ";
// Execute query
$result = mysqli_query($conn, $sql);
// Check if query executed successfully
if ($result && mysqli_num_rows($result) > 0) {
    // Fetch the student name
    $row = mysqli_fetch_assoc($result);
    $student_name = $row['student_name'];
    $student_degree = $row['student_degree'];
    $student_campus = $row['student_campus'];
    $student_batch = $row['student_batch'];
    $student_cnic = $row['student_cnic'];
    $student_father = $row['student_father_name'];
    $student_email = $row['student_email'];
} else {
    // Handle case where student data is not found
    $student_name = "Unknown";
}

$course_names = [];
$sql_second = " select course_name from courses join grades on courses.course_id = grades.course_id where student_id = '$student_id' ";

$result_second = mysqli_query($conn, $sql_second);

if ($result_second && mysqli_num_rows($result_second) > 0) {
    while ($row = mysqli_fetch_assoc($result_second)) {
        $course_names[] = $row['course_name'];
    }
} else {
    echo "No courses found.";
}

$grades = [];

$sql_third = "SELECT courses.course_name, grades.grade 
              FROM courses 
              JOIN grades ON courses.course_id = grades.course_id 
              WHERE student_id = '$student_id' ";

$result_third = mysqli_query($conn, $sql_third);

if ($result_third && mysqli_num_rows($result_third) > 0) {
    // Fetch both course names and grades and store them in the array
    while ($row = mysqli_fetch_assoc($result_third)) {
        $grades[] = $row; // Store the entire row, containing both course name and grade
    }
} else {
    echo "No grades found.";
}

$course_names1 = [];
$date = [];
$status = [];

$sql_fourth = "SELECT course_name, date, status FROM attendances JOIN courses ON attendances.course_id = courses.course_id WHERE student_id = '$student_id'";

$result_fourth = mysqli_query($conn, $sql_fourth);

if ($result_fourth && mysqli_num_rows($result_fourth) > 0) {
    // Fetch both course names, dates, and statuses and store them in the arrays
    while ($row = mysqli_fetch_assoc($result_fourth)) {
        $course_names1[] = $row['course_name'];
        $date[] = $row['date'];
        $status[] = $row['status'];
    }
} else {
    echo "No grades found.";
}







// Close connection
mysqli_close($conn); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Portal</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f9fa; /* Light gray background */
    }
    .sidebar {
        width: 200px;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        background-color: #343a40; /* Dark background color */
        padding-top: 20px;
        transition: width 0.3s; /* Smooth width transition */
        z-index: 1; /* Ensure sidebar is above other content */
    }
    .sidebar a {
        display: flex; /* Use flexbox for layout */
        flex-direction: column; /* Stack symbol and title vertically */
        align-items: center; /* Center-align items horizontally */
        width: 100%;
        padding: 20px 10px; /* Updated padding for larger buttons */
        margin-bottom: 5px;
        text-align: center;
        text-decoration: none;
        color: #ced4da; /* Light text color */
        transition: background-color 0.3s, color 0.3s; /* Smooth color transition */
    }
    .sidebar a:hover {
        background-color: #495057; /* Darker background color on hover */
        color: #fff; /* White text color on hover */
    }
    .icon {
        font-size: 1.5em; /* Larger font size for symbol */
        margin-bottom: 5px; /* Add some space between symbol and title */
    }
    .container {
        margin-left: 200px; /* Adjusted margin for sidebar width */
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
    }
    .section {
        display: none; /* Hide all sections initially */
    }
    .section.active {
        display: block; /* Show active section */
    }
    .welcome {
        font-size: 24px;
        text-align: center;
        margin-bottom: 20px;
        color: #333; /* Dark text color */
    }

    /* Additional styling for the info section in the home button */
    #home .info {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        margin-top: 20px; /* Add some space between welcome message and info section */
    }
    #home .info div {
        padding: 10px;
        border-bottom: 1px solid #ccc;
    }
    #home .info div:last-child {
        border-bottom: none;
    }
    #home .info div strong {
        color: #333;
    }


</style>
</head>
<body>

<div class="sidebar">
    <a href="#" class="button" onclick="showSection('home')">
        <span class="icon">🏠</span>
        <span class="title">Home</span>
    </a>
    <a href="#" class="button" onclick="showSection('courses')">
        <span class="icon">📚</span>
        <span class="title">My Courses</span>
    </a>
    <a href="#" class="button" onclick="showSection('attendance')">
        <span class="icon">📅</span>
        <span class="title">Attendance</span>
    </a>
    <a href="#" class="button" onclick="showSection('grades')">
        <span class="icon">📊</span>
        <span class="title">Grades</span>
    </a>
    <a href="#" class="button" onclick="showSection('schedule')">
        <span class="icon">📆</span>
        <span class="title">Class Schedule</span>
    </a>
</div>

<div class="container">

    <div id="home" class="section active">
        <div class="welcome">Welcome to the Student Portal!</div>
        <!-- University and personal information -->
        <h2>University Information</h2>
        <div class="info">
            <div>
                <strong>Name:</strong> <?php echo $student_name; ?>
            </div>
            <div>
                <strong>Degree:</strong> <?php echo $student_degree; ?>
            </div>
            <div>
                <strong>Campus:</strong> <?php echo $student_campus; ?>
            </div>
        
            <div>
                <strong>Batch:</strong> <?php echo $student_batch; ?>
            </div>
        </div>
        <h2>Personal Information</h2>
        <div class="info">
            <div>
                <strong>CNIC:</strong> <?php echo $student_cnic; ?>
            </div>
            <div>
                <strong>Father Name:</strong> <?php echo $student_father; ?>
            </div>
            <div>
                <strong>Email:</strong> <?php echo $student_email; ?>
            </div>
        </div>
    </div>


    <div id="courses" class="section">
    <div class="welcome">Explore Your Courses</div>
    <table>
        <thead>
            <tr>
                <th> <h2>COURSES</h2></th>
            </tr>
        </thead>
        <tbody>
        <?php
            // Loop through the $course_names array and print each course name in a table row
            foreach ($course_names as $course_name) {
                echo "<tr>";
                echo "<td>" . $course_name . "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
    </div>
    
<div id="attendance" class="section">
    <div class="welcome">Track Your Attendance</div>
    <table>
        <thead>
            <tr>
                <th><h2>COURSE</h2></th>
                <th><h2>DATE</h2></th>
                <th><h2>STATUS</h2></th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Loop through the arrays to print course names, dates, and statuses
            foreach ($status as $key => $value) {
                echo "<tr>";
                echo "<td>" . $course_names1[$key] . "</td>";
                echo "<td>" . $date[$key] . "</td>";
                echo "<td>" . $value . "</td>";
                echo "</tr>";
            }
            
            ?>
        </tbody>
    </table>
</div>



    
    <div id="grades" class="section">
    <div class="welcome">Your Course Grades</div>
    <table>
        <thead>
            <tr>
                <th><h2>COURSE</h2></th>
                <th><h2>GRADE</h2></th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Loop through $grades array to display both course names and grades
            foreach ($grades as $row) {
                echo "<tr>";
                echo "<td>" . $row['course_name'] . "</td>"; // Access the course name
                echo "<td>" . $row['grade'] . "</td>"; // Access the grade
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
    </div>



    

    <div id="schedule" class="section">
        <div class="welcome">Check Your Class Schedule</div>
        <!-- Class schedule viewing section content -->
    </div>


</div>

<script>
function showSection(sectionName) {
    var sections = document.querySelectorAll('.section');
    sections.forEach(function(section) {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');
    console.log("Toggled section: " + sectionName);
}
</script>

</body>
</html>


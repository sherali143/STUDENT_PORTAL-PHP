<?php

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

if(isset($_GET['instructor_id']) && isset($_GET['course_id']))
{
    $course_id= $_GET['course_id'];
    $course_name= $_GET['course_name'];
    $course_title= $_GET['course_title'];
    $instructor_id = $_GET['instructor_id'];
    // Perform the database update
    $sql = "insert into courses (course_id,course_name,course_title,instructor_id) values ('$course_id','$course_name','$course_title','$instructor_id')";

    $result = mysqli_query($conn, $sql);

    if($result) 
    {
        if(mysqli_affected_rows($conn))
        {
            echo "Courses ADDED successfully.";
        }
        else
        {
            echo "No record Found For this Student";
        }
        
    } 
    else
    {
        echo "Error Adding Teachers: " . mysqli_error($conn);
    }
} 


?>

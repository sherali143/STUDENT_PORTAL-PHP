<?php
session_start();

if(!isset($_SESSION['instructor_id']))
{
    header("Location: login_teacher.php");
    exit();
}
$instructor_id = $_SESSION['instructor_id'];

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

$sql1= "SELECT course_id from courses where courses.instructor_id= '$instructor_id'";

$result1= mysqli_query($conn,$sql1);

if(mysqli_num_rows($result1) > 0)
{
    $row= mysqli_fetch_assoc($result1);
    $course_id= $row['course_id'];
}

if(isset($_GET['student_id']) && isset($_GET['grade'])) 
{
    $student_id = $_GET['student_id'];
    $grade = $_GET['grade'];
    // Perform the database update
    $sql = "insert into grades(student_id,course_id,grade) values ('$student_id','$course_id','$grade')";

    $result = mysqli_query($conn, $sql);

    if($result) 
    {
        if(mysqli_affected_rows($conn))
        {
            echo "GRADE ADDED successfully.";
        }
        else
        {
            echo "No record Found For this Student";
        }
        
    } 
    else
    {
        echo "Error Adding grade: " . mysqli_error($conn);
    }
} 


?>

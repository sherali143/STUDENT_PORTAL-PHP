<?php
session_start();

if(!isset($_SESSION['instructor_id']))
{
    header("Location: login_teacher.php");
    exit();
}
$instructor_id = $_SESSION['instructor_id'];

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

$sql1= "SELECT course_id from courses where courses.instructor_id= '$instructor_id'";

$result1= mysqli_query($conn,$sql1);

if(mysqli_num_rows($result1) > 0)
{
    $row= mysqli_fetch_assoc($result1);
    $course_id= $row['course_id'];
}


if(isset($_GET['student_id']) && isset($_GET['date'])) 
{
    $student_id = $_GET['student_id'];
    $date = $_GET['date'];
    
    // Perform the database update
    $sql = "DELETE from attendances where student_id = '$student_id' and course_id = '$course_id' and date= '$date' ";

    $result = mysqli_query($conn, $sql);

    if($result)
    {
        if(mysqli_affected_rows($conn)>0)
        {   
            echo "ATTENDANCE DELETE SUCESSFULLY";

        }
        else
        {
            echo "NO RECORD FOUND FOR THE STUDENT";
        }
     
    } 
    else
     {
        echo "Error updating grade: " . mysqli_error($conn);
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Portal</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f9fa; /* Light gray background */
    }
    .sidebar {
        width: 200px;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        background-color: #343a40; /* Dark background color */
        padding-top: 20px;
        transition: width 0.3s; /* Smooth width transition */
        z-index: 1; /* Ensure sidebar is above other content */
    }
    .sidebar a {
        display: flex; /* Use flexbox for layout */
        flex-direction: column; /* Stack symbol and title vertically */
        align-items: center; /* Center-align items horizontally */
        width: 100%;
        padding: 15px;
        margin-bottom: 5px;
        text-align: center;
        text-decoration: none;
        color: #ced4da; /* Light text color */
        transition: background-color 0.3s, color 0.3s; /* Smooth color transition */
    }
    .sidebar a:hover {
        background-color: #495057; /* Darker background color on hover */
        color: #fff; /* White text color on hover */
    }
    .icon {
        font-size: 1.2em; /* Larger font size for symbol */
        margin-bottom: 5px; /* Add some space between symbol and title */
    }
    .container {
        margin-left: 200px; /* Adjusted margin for sidebar width */
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
    }
    .section {
        display: none; /* Hide all sections initially */
    }
    .section.active {
        display: block; /* Show active section */
    }
</style>
</head>
<body>

<div class="sidebar">
    <a href="#" class="button" onclick="showSection('home')">
        <span class="icon">🏠</span>
        <span class="title">Home</span>
    </a>
    <a href="#" class="button" onclick="showSection('registration')">
        <span class="icon">📝</span>
        <span class="title">Course Registration</span>
    </a>
    <a href="#" class="button" onclick="showSection('attendance')">
        <span class="icon">📅</span>
        <span class="title">Attendance</span>
    </a>
    <a href="#" class="button" onclick="showSection('marks')">
        <span class="icon">📊</span>
        <span class="title">Marks</span>
    </a>
    <a href="#" class="button" onclick="showSection('fees')">
        <span class="icon">💵</span>
        <span class="title">Fee Detail</span>
    </a>
</div>

<div class="container">
    <div id="home" class="section active">
        <!-- Home section content -->
    </div>
    <div id="registration" class="section">
        <!-- Course registration section content -->
    </div>
    <div id="attendance" class="section">
        <!-- Attendance section content -->
    </div>
    <div id="marks" class="section">
        <!-- Marks section content -->
    </div>
    <div id="fees" class="section">
        <!-- Fee detail section content -->
    </div>
</div>

<script>
function showSection(sectionName) {
    var sections = document.querySelectorAll('.section');
    sections.forEach(function(section) {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');
}
</script>

</body>
</html>

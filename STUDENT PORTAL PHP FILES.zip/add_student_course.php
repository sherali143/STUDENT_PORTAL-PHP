<?php

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

if(isset($_GET['student_id']) && isset($_GET['course_id']))  
{
    $student_id =   $_GET['student_id'];
    $course_id = $_GET['course_id'];
   
    // Perform the database update
    $sql = "insert into student_course(student_id,course_id) values ('$student_id','$course_id')";

    $result = mysqli_query($conn, $sql);

    if($result) 
    {
        if(mysqli_affected_rows($conn))
        {
            echo "Student Course ADDED successfully.";
        }
        else
        {
            echo "No record Found For this Student";
        }
        
    } 
    else
    {
        echo "Error Adding Student: " . mysqli_error($conn);
    }
} 


?>

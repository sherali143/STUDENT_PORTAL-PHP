<?php

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

if(isset($_GET['instructor_id']) && isset($_GET['instructor_name'])  && isset($_GET['instructor_title']) && isset($_GET['instructor_email']) && isset($_GET['instructor_password'])); 
{
    $student_id =   $_GET['student_id'];
    $student_name = $_GET['student_name'];
    $student_batch = $_GET['student_batch'];
    $student_cnic = $_GET['student_cnic'];
    $student_father_name = $_GET['student_father_name'];
    $student_campus = $_GET['student_campus'];
    $student_degree = $_GET['student_degree'];
    $student_email = $_GET['student_email'];
    $password = $_GET['password'];
   
    // Perform the database update
    $sql = "insert into student_personal_information  values ('$student_id','$student_name', '$student_batch','$student_cnic', '$student_father_name', '$student_campus', '$student_degree', '$student_email', '$password')";

    $result = mysqli_query($conn, $sql);

    if($result) 
    {
        if(mysqli_affected_rows($conn))
        {
            echo "Student ADDED successfully.";
        }
        else
        {
            echo "No record Found For this Student";
        }
        
    } 
    else
    {
        echo "Error Adding Student: " . mysqli_error($conn);
    }
} 


?>

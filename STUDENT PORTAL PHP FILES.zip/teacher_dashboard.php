<?php
session_start();

if (!isset($_SESSION['instructor_id'])) 
{
    header("Location: login_teacher.php");
    exit(); // Stop further execution
}

// Retrieve the student ID from the session
$instructor_id = $_SESSION['instructor_id'];

// Initialize student name variable
$instructor_name = "";
$instructor_title = "";
$instructor_email = "";
$instructor_password = "";
$course_name = "";

// Database connection parameters
$server_name = "localhost";
$user_name = "root";
$password = "";
$database = "student_portal";

// Create connection
$conn = mysqli_connect($server_name, $user_name, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = " select instructor_name,instructor_title,instructor_email,instructor_password,courses.course_name from courses join instructors on instructors.instructor_id = courses.instructor_id where instructors.instructor_id = '$instructor_id' ";
$result = mysqli_query($conn,$sql);
if ($result && (mysqli_num_rows($result)>0))
{
    $row = mysqli_fetch_assoc($result);
    $instructor_name = $row['instructor_name'];
    $instructor_title = $row['instructor_title'];
    $instructor_email = $row['instructor_email'];
    $instructor_password = $row['instructor_password'];
    $course_name=$row['course_name'];
}

else{
    echo "Error contact admin!";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teacher Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
<style>
    body {
        font-family: 'Montserrat', sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f6f6f6; /* Light gray background */
    }
    .sidebar {
        width: 200px;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        background-color: #333; /* Dark background color */
        padding-top: 20px;
        transition: width 0.3s; /* Smooth width transition */
        z-index: 1; /* Ensure sidebar is above other content */
    }
    .sidebar a {
        display: flex; /* Use flexbox for layout */
        flex-direction: column; /* Stack symbol and title vertically */
        align-items: center; /* Center-align items horizontally */
        width: 100%;
        padding: 15px;
        margin-bottom: 5px;
        text-align: center;
        text-decoration: none;
        color: #fff; /* White text color */
        transition: background-color 0.3s, color 0.3s; /* Smooth color transition */
    }
    .sidebar a:hover {
        background-color: #555; /* Darker background color on hover */
    }
    .icon {
        font-size: 1.5em; /* Larger font size for symbol */
        margin-bottom: 5px; /* Add some space between symbol and title */
    }
    .container {
        margin-left: 200px; /* Adjusted margin for sidebar width */
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
    }
    .section {
        display: none; /* Hide all sections initially */
    }
    .section.active {
        display: block; /* Show active section */
    }
    .welcome {
        font-size: 24px;
        text-align: center;
        margin-bottom: 20px;
        color: #333; /* Dark text color */
    }
</style>
</head>
<body>

<div class="sidebar">
    <a href="#" class="button" onclick="showSection('home')">
        <span class="icon">🏠</span>
        <span class="title">Dashboard</span>
    </a>
    <a href="#" class="button" onclick="showSection('courses')">
        <span class="icon">📚</span>
        <span class="title">Courses</span>
    </a>
    <a href="#" class="button" onclick="showSection('attendance')">
        <span class="icon">📅</span>
        <span class="title">Attendance</span>
    </a>
    <a href="#" class="button" onclick="showSection('grades')">
        <span class="icon">📊</span>
        <span class="title">Grades</span>
    </a>
    <a href="#" class="button" onclick="showSection('communication')">
        <span class="icon">✉️</span>
        <span class="title">Communication</span>
    </a>
</div>

<div class="container">

<div id="home" class="section active">
    <h2>Teacher Information</h2>
    <div class="info">
        <table>
            <tr>
                <td><strong>Name:</strong> <?php echo $instructor_name ?></td>
                <td><strong>Title:</strong> <?php echo $instructor_title ?></td>
            </tr>
            <tr>
                <td><strong>Email:</strong> <?php echo $instructor_email ?></td>
                <td><strong>Password:</strong> <?php echo $instructor_password ?></td>
            </tr>
            <tr>
                <td colspan="2"><strong>Course:</strong> <?php echo $course_name ?></td>
            </tr>
        </table>
    </div>
</div>



<div id="courses" class="section">
    <div class="welcome">Manage Your Courses</div>
    <h2>STUDENTS ENROLL</h2>

    <?php
    $sql1 = "SELECT student_id FROM student_course JOIN courses ON courses.course_id = student_course.course_id WHERE courses.instructor_id = '$instructor_id'";
    $result1 = mysqli_query($conn, $sql1);

    if ($result1 && mysqli_num_rows($result1) > 0) 
    {
        echo "<div class=\"student-list\">";
        while ($row = mysqli_fetch_assoc($result1)) 
        {
            echo "<div>STUDENT ID: " . $row['student_id'] . "</div>";
        }
        echo "</div>";
    } 
    else 
    {
        echo "<div>No record Found For students</div>";
    }
    ?>
</div>

    <div id="attendance" class="section">
        <div class="welcome">Take Attendance</div>
        <h2>ATTENDANCE LIST</h2>

        <?php

    $sql2 = "select attendances.student_id , attendances.date, attendances.status from attendances join courses on attendances.course_id = courses.course_id where instructor_id = '$instructor_id'";
    $result2 = mysqli_query($conn, $sql2);

    if ($result2 && mysqli_num_rows($result2) > 0) 
    {
        echo "<table>";
        echo "<tr><th>Student ID</th><th>Date</th><th>Status</th></tr>";
        while ($row = mysqli_fetch_assoc($result2)) 
        {
            echo "<tr>";
            echo "<td>" . $row['student_id'] . "</td>";
            echo "<td>" . $row['date'] . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "</tr>";
    }
    echo "</table>";
    echo "<button onclick ='update_attendance()'>Update</button>";
    echo "<button onclick ='add_attendance()'>ADD</button>";
    echo "<button onclick ='delete_attendance()'>DELETE</button>";

    } 
    else 
    {
        echo "<div>No record Found For students</div>";
    }

?>
        <!-- Attendance section content -->
    </div>

    <div id="grades" class="section">
    <div class="welcome">Manage Grades</div>
    <h2>GRADES OF STUDENTS</h2>

    <?php
    $sql3 = "SELECT student_id, grade FROM courses JOIN grades ON courses.course_id = grades.course_id WHERE instructor_id = '$instructor_id'";
    $result3 = mysqli_query($conn, $sql3);

    if ($result3 && mysqli_num_rows($result3) > 0) {
        echo "<table>";
        echo "<tr><th>Student ID</th><th>GRADE</th></tr>";
        while ($row = mysqli_fetch_assoc($result3)) {
            echo "<tr>";
            echo "<td>" . $row['student_id'] . "</td>";
            echo "<td>" . $row['grade'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<button onclick='update_grade()'>Update</button>";
        echo "<button onclick='add_grade()'>ADD</button>";

    } 
    else 
    {
        echo "<div>No record Found For students</div>";
    }
?>


    <!-- Grade management section content -->
</div>

    <div id="communication" class="section">
        <div class="welcome">Communicate with Students</div>
        <!-- Communication section content -->
    </div>

</div>

<script>
function showSection(sectionName) {
    var sections = document.querySelectorAll('.section');
    sections.forEach(function(section) {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');
}
</script>

<script>

function update_grade() {
    var student_id = prompt("Enter the student ID:");
    var new_grade = prompt("Enter the new grade:");
    if (student_id && new_grade) {
        // Redirect to update_grade.php with studentId and newGrade as parameters
        window.location.href = "update_grade.php?student_id=" + student_id + "&new_grade=" + new_grade;
    }
}
</script>

<script>

    function update_attendance(){
        var student_id = prompt("Enter the student id:");
        var date= prompt("Enter the date on which you want to update attendance");
        var new_status= prompt("Enter the new status");

        if(student_id && date && new_status)
        {
            window.location.href= "update_attendance.php?student_id=" + student_id + "&date=" + date + "&new_status=" + new_status;
        }
    }

</script>

<script>
    function add_attendance() {
    var student_id = prompt("Enter the student id for which you want to add attendance:");
    var date = prompt("Enter the date on which you want to add attendance:");
    var attendance = prompt("Enter the status:");

    if (student_id && date && attendance) {
        window.location.href = "add_attendance.php?student_id=" + student_id + "&date=" + date + "&status=" + attendance ;
    }
}

</script>
<script>
    function delete_attendance()
    {
        var student_id = prompt("Enter the student_id");
        var date = prompt("Enter the Date");

        window.location.href= "delete_attendance.php?student_id="+ student_id + "&date=" + date;
    }
    
</script>


<script>

    function add_grade()
    {
        var student_id = prompt("Enter the student_id");
        var grade = prompt("Enter the grade");
        window.location.href= "add_grade.php?student_id="+ student_id + "&grade=" + grade;

    }

</script>

</body>
</html>

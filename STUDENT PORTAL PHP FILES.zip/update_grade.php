<?php
session_start();

if(!isset($_SESSION['instructor_id']))
{
    header("Location: login_teacher.php");
    exit();
}
$instructor_id = $_SESSION['instructor_id'];

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

if(isset($_GET['student_id']) && isset($_GET['new_grade'])) 
{
    $student_id = $_GET['student_id'];
    $new_grade = $_GET['new_grade'];

    // Perform the database update
    $sql = "UPDATE grades
    JOIN courses ON grades.course_id = courses.course_id
    SET grades.grade = '$new_grade'
    WHERE courses.instructor_id = '$instructor_id'
    AND grades.student_id = '$student_id' ";

    $result = mysqli_query($conn, $sql);

    if($result) {
        echo "Grade updated successfully.";
    } else {
        echo "Error updating grade: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request.";
}
?>

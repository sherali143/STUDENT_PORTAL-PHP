<?php
session_start();

if(!isset($_SESSION['instructor_id']))
{
    header("Location: login_teacher.php");
    exit();
}
$instructor_id = $_SESSION['instructor_id'];

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

if(isset($_GET['student_id']) && isset($_GET['date']) && isset($_GET['new_status'])) 
{
    $student_id = $_GET['student_id'];
    $date = $_GET['date'];
    $new_status= $_GET['new_status'];

    // Perform the database update
    $sql = "UPDATE attendances JOIN courses ON attendances.course_id = courses.course_id SET attendances.status = '$new_status' WHERE courses.instructor_id = '$instructor_id' AND attendances.student_id = '$student_id' AND attendances.date = '$date' ";

    $result = mysqli_query($conn, $sql);

    if($result) 
    {
        if(mysqli_affected_rows($conn))
        {
            echo "ATTENDANCES UPDATED SUCESSFULLY";
        }
        else
        {
            echo "NO RECORD FOUND FOR THIS STUDENT ";
        }
       
    } 
    else 
    {
        echo "Error updating grade: " . mysqli_error($conn);
    }
} 
else 
{
    echo "Invalid request.";
}
?>

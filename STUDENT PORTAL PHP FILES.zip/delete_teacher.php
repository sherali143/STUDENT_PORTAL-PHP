<?php

$server_name="localhost";
$user_name="root";
$password="";
$database="student_portal";

$conn= mysqli_connect($server_name,$user_name,$password,$database);

if(isset($_GET['instructor_id']))
{
    $instructor_id =   $_GET['instructor_id'];
    // Perform the database update
    $sql = "delete from instructors where instructor_id= '$instructor_id'";
    $result = mysqli_query($conn, $sql);

    if($result) 
    {
        if(mysqli_affected_rows($conn))
        {
            echo "Teacher DELETED successfully.";
        }
        else
        {
            echo "No record Found For this TEACHER";
        }
        
    } 
    else
    {
        echo "Error Deleting Teachers: " . mysqli_error($conn);
    }
} 


?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nutec";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $rollno = mysqli_real_escape_string($conn, $_REQUEST['rollno'] ?? '');
    $name = mysqli_real_escape_string($conn, $_REQUEST['name'] ?? '');
    $email = mysqli_real_escape_string($conn, $_REQUEST['email'] ?? '');
    $department = mysqli_real_escape_string($conn, $_REQUEST['department'] ?? '');
    $event = mysqli_real_escape_string($conn, $_REQUEST['event'] ?? '');

    // Attempt insert query execution
    $sql = "INSERT INTO registrations (rollno, name, email, department, event) VALUES ('$rollno', '$name', '$email', '$department', '$event')";
    if(mysqli_query($conn, $sql)){
        echo "Records added successfully.";
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
}

// Close connection
mysqli_close($conn);
?>



<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
</head>
<body>
    <h2>Student Registration Form</h2>
    <form action="insert_data.php" method="POST">
        <label for="rollno">Roll No:</label><br>
        <input type="text" id="rollno" name="rollno"><br><br>
        
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name"><br><br>
        
        <label for="email">Email:</label><br>
        <input type="text" id="email" name="email"><br><br>
        
        <label for="department">Department:</label><br>
        <select id="department" name="department">
            <option value="computer_science">Computer Science</option>
            <option value="software_engineering">Software Engineering</option>
            <option value="electrical_engineering">Electrical Engineering</option>
        </select><br><br>
        
        <label for="event">Choose Event:</label><br>
        <select id="event" name="event">
            <option value="speed_programming">Speed Programming</option>
            <option value="debate">Debate</option>
            <option value="typing">Typing</option>
            <option value="egaming">E-Gaming</option>
        </select><br><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>
